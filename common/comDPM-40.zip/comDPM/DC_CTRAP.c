 /*
  C:\PROJECTS\ICECUBE\DOR_REV1\FPGA\DCOM\DC_CTRAP.c
  C code created by Visual Software Solution's StateCAD 4.11
  Tue Mar 21 09:03:18 2006


  This C code was generated using: 
  one-hot state assignment with boolean code format. 
  Minimization is enabled,  implied else is enabled,  
  and outputs are speed optimized. 
*/

#include "DC_CTRAP.h"

enum _sreg_TYPE sreg, __sreg;
enum _sreg1_TYPE sreg1, __sreg1;
char bfstat_rcvd=0,comres_rcvd=0,data_rcvd=0,del_15us=0,del_30us=0;
char dpr_rx_aff=0,dpr_tx_ef=0,drreq_rcvd=0,id_data_avail=0,idle_rcvd=0;
char idreq_rcvd=0,msg_sent=0,pulse_rcvd=0,pulse_sent=0,reboot_req=0;
char RES=0,sysres_rcvd=0,tcal_rcvd=0,time_bit_5=0;
char buf_res,__buf_res,cmd_snd0,__cmd_snd0,cmd_snd1,__cmd_snd1,cmd_snd2,
	__cmd_snd2,cmd_snd3,__cmd_snd3;
char com_avail,__com_avail,COMM_RESET,__COMM_RESET,reboot_gnt,__reboot_gnt,
	rec_ena,__rec_ena,send_ctrl,__send_ctrl;
char send_data,__send_data,send_id,__send_id,send_tcal,__send_tcal,tcal_cyc,
	__tcal_cyc,tcal_data,__tcal_data;
char tcal_prec,__tcal_prec,tcal_psnd,__tcal_psnd,timer_clrn,__timer_clrn;
unsigned long sto,__sto;
int _clock=0,_error=0,_warning=0; /* Trace variables*/

main() {

	/*bfstat_rcvd,comres_rcvd,data_rcvd,del_15us,del_30us,dpr_rx_aff,dpr_tx_ef,
		drreq_rcvd,id_data_avail,idle_rcvd,idreq_rcvd,msg_sent,pulse_rcvd,pulse_sent,
		reboot_req,RES,sysres_rcvd,tcal_rcvd,time_bit_5*/
	condition(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	_DC_CTRAP(1); /*Power up*/
	/*sreg, sreg1,buf_res,cmd_snd0,cmd_snd1,cmd_snd2,cmd_snd3,com_avail,
		COMM_RESET,reboot_gnt,rec_ena,send_ctrl,send_data,send_id,send_tcal,tcal_cyc,
		tcal_data,tcal_prec,tcal_psnd,timer_clrn*/
	check_result(_sreg_UNKNOWN, _sreg1_UNKNOWN,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
		,0);

	error_count();
	return(1);
}

void _DC_CTRAP(char _powerup) {
	char _current_state1[64];
	char _current_state2[64];
	strcpy(_current_state1,"_sreg_UNKNOWN");
	strcpy(_current_state2,"_sreg1_UNKNOWN");
	trace_in(_powerup);

	if (_powerup) {
		/*Power up to unknown state*/
		sreg = _sreg_UNKNOWN;

		strcpy(_current_state1,"_sreg_UNKNOWN");
		sreg1 = _sreg1_UNKNOWN;

		strcpy(_current_state2,"_sreg1_UNKNOWN");

		/*Reset outputs/logic*/
		buf_res=0;
		cmd_snd0=0;
		cmd_snd1=0;
		cmd_snd2=0;
		cmd_snd3=0;
		com_avail=0;
		COMM_RESET=0;
		reboot_gnt=0;
		rec_ena=0;
		send_ctrl=0;
		send_data=0;
		send_id=0;
		send_tcal=0;
		tcal_cyc=0;
		tcal_data=0;
		tcal_prec=0;
		tcal_psnd=0;
		timer_clrn=0;
		contract_vectors();

	} else {
		expand_vectors();
		__sto=sto;

		__sreg=sreg;
		__sreg1=sreg1;
		__buf_res=buf_res;
		__cmd_snd0=cmd_snd0;
		__cmd_snd1=cmd_snd1;
		__cmd_snd2=cmd_snd2;
		__cmd_snd3=cmd_snd3;
		__com_avail=com_avail;
		__COMM_RESET=COMM_RESET;
		__reboot_gnt=reboot_gnt;
		__rec_ena=rec_ena;
		__send_ctrl=send_ctrl;
		__send_data=send_data;
		__send_id=send_id;
		__send_tcal=send_tcal;
		__tcal_cyc=tcal_cyc;
		__tcal_data=tcal_data;
		__tcal_prec=tcal_prec;
		__tcal_psnd=tcal_psnd;
		__timer_clrn=timer_clrn;


		/*-----Reset outputs -----*/
		buf_res=0;
		cmd_snd0=0;
		cmd_snd1=0;
		cmd_snd2=0;
		cmd_snd3=0;
		com_avail=0;
		COMM_RESET=0;
		reboot_gnt=0;
		rec_ena=0;
		send_ctrl=0;
		send_data=0;
		send_id=0;
		send_tcal=0;
		tcal_cyc=0;
		tcal_data=0;
		tcal_prec=0;
		tcal_psnd=0;
		timer_clrn=0;


		/* -------- machine sreg ---------- */
		if ( RES ) {
			sreg=PON;

			sto= 0x0;
			strcpy(_current_state1,"PON");
		} else {
			switch(sreg) {
				case CLR_BUF:
					sreg=SND_IDLE;

					sto= 0xf1;
					strcpy(_current_state1,"SND_IDLE");
				break;
				case CLR_TIMER_1:
					sreg=SEND_WT_1;

					sto= 0x4100;
					strcpy(_current_state1,"SEND_WT_1");
				break;
				case CLR_TIMER_2:
					sreg=SEND_WT_2;

					sto= 0x4100;
					strcpy(_current_state1,"SEND_WT_2");
				break;
				case CMD_WAIT:
					if ( !idle_rcvd & !drreq_rcvd & !sysres_rcvd & !data_rcvd & !bfstat_rcvd
						 & !idreq_rcvd & !comres_rcvd & !tcal_rcvd  |  !idle_rcvd & !drreq_rcvd & !
						sysres_rcvd & !data_rcvd & !bfstat_rcvd & !id_data_avail & !comres_rcvd & !
						tcal_rcvd ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( idle_rcvd ) {
						sreg=SND_IDLE;

						sto= 0xf1;
						strcpy(_current_state1,"SND_IDLE");
					}
					if ( drreq_rcvd & reboot_req & dpr_tx_ef ) {
						sreg=SND_DRBT;

						sto= 0x71;
						strcpy(_current_state1,"SND_DRBT");
					}
					if ( sysres_rcvd ) {
						sreg=SYS_RESET;

						sto= 0x1000;
						strcpy(_current_state1,"SYS_RESET");
					}
					if ( data_rcvd & dpr_rx_aff  |  bfstat_rcvd & dpr_rx_aff ) {
						sreg=SND_MRNB;

						sto= 0x91;
						strcpy(_current_state1,"SND_MRNB");
					}
					if ( drreq_rcvd & dpr_tx_ef & !reboot_req ) {
						sreg=SND_DRAND;

						sto= 0x61;
						strcpy(_current_state1,"SND_DRAND");
					}
					if ( drreq_rcvd & !dpr_tx_ef ) {
						sreg=SND_DAT;

						sto= 0x2;
						strcpy(_current_state1,"SND_DAT");
					}
					if ( data_rcvd & !dpr_rx_aff  |  bfstat_rcvd & !dpr_rx_aff ) {
						sreg=SND_MRWB;

						sto= 0x81;
						strcpy(_current_state1,"SND_MRWB");
					}
					if ( idreq_rcvd & id_data_avail ) {
						sreg=SND_ID;

						sto= 0x18;
						strcpy(_current_state1,"SND_ID");
					}
					if ( comres_rcvd ) {
						sreg=CLR_BUF;

						sto= 0x8000;
						strcpy(_current_state1,"CLR_BUF");
					}
					if ( tcal_rcvd ) {
						sreg=REC_WT;

						sto= 0x14100;
						strcpy(_current_state1,"REC_WT");
					}
				break;
				case CRES_WAIT:
					if ( comres_rcvd ) {
						sreg=CLR_BUF;

						sto= 0x8000;
						strcpy(_current_state1,"CLR_BUF");
					}
					if ( !comres_rcvd ) {
						sreg=CRES_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CRES_WAIT");
					}
				break;
				case DOM_REBOOT:
					sreg=DOM_REBOOT;

					sto= 0x2000;
					strcpy(_current_state1,"DOM_REBOOT");
				break;
				case PON:
					if ( time_bit_5 ) {
						sreg=CRES_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CRES_WAIT");
					}
					if ( !time_bit_5 ) {
						sreg=PON;

						sto= 0x0;
						strcpy(_current_state1,"PON");
					}
				break;
				case REC_PULSE:
					if ( !pulse_rcvd & !del_30us ) {
						sreg=REC_PULSE;

						sto= 0x14300;
						strcpy(_current_state1,"REC_PULSE");
					}
					if ( pulse_rcvd & !del_30us ) {
						sreg=CLR_TIMER_1;

						sto= 0x100;
						strcpy(_current_state1,"CLR_TIMER_1");
					}
					if ( del_30us ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
				break;
				case REC_WT:
					if ( del_15us ) {
						sreg=REC_PULSE;

						sto= 0x14300;
						strcpy(_current_state1,"REC_PULSE");
					}
					if ( !del_15us ) {
						sreg=REC_WT;

						sto= 0x14100;
						strcpy(_current_state1,"REC_WT");
					}
				break;
				case SEND_WT_1:
					if ( del_15us ) {
						sreg=SND_PULSE;

						sto= 0x4500;
						strcpy(_current_state1,"SND_PULSE");
					}
					if ( !del_15us ) {
						sreg=SEND_WT_1;

						sto= 0x4100;
						strcpy(_current_state1,"SEND_WT_1");
					}
				break;
				case SEND_WT_2:
					if ( del_30us ) {
						sreg=SND_TC_DAT;

						sto= 0x904;
						strcpy(_current_state1,"SND_TC_DAT");
					}
					if ( !del_30us ) {
						sreg=SEND_WT_2;

						sto= 0x4100;
						strcpy(_current_state1,"SEND_WT_2");
					}
				break;
				case SND_DAT:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_DAT;

						sto= 0x2;
						strcpy(_current_state1,"SND_DAT");
					}
				break;
				case SND_DRAND:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_DRAND;

						sto= 0x61;
						strcpy(_current_state1,"SND_DRAND");
					}
				break;
				case SND_DRBT:
					if ( msg_sent ) {
						sreg=DOM_REBOOT;

						sto= 0x2000;
						strcpy(_current_state1,"DOM_REBOOT");
					}
					if ( !msg_sent ) {
						sreg=SND_DRBT;

						sto= 0x71;
						strcpy(_current_state1,"SND_DRBT");
					}
				break;
				case SND_ID:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_ID;

						sto= 0x18;
						strcpy(_current_state1,"SND_ID");
					}
				break;
				case SND_IDLE:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_IDLE;

						sto= 0xf1;
						strcpy(_current_state1,"SND_IDLE");
					}
				break;
				case SND_MRNB:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_MRNB;

						sto= 0x91;
						strcpy(_current_state1,"SND_MRNB");
					}
				break;
				case SND_MRWB:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_MRWB;

						sto= 0x81;
						strcpy(_current_state1,"SND_MRWB");
					}
				break;
				case SND_PULSE:
					if ( pulse_sent ) {
						sreg=CLR_TIMER_2;

						sto= 0x100;
						strcpy(_current_state1,"CLR_TIMER_2");
					}
					if ( !pulse_sent ) {
						sreg=SND_PULSE;

						sto= 0x4500;
						strcpy(_current_state1,"SND_PULSE");
					}
				break;
				case SND_TC_DAT:
					if ( msg_sent ) {
						sreg=CMD_WAIT;

						sto= 0x10000;
						strcpy(_current_state1,"CMD_WAIT");
					}
					if ( !msg_sent ) {
						sreg=SND_TC_DAT;

						sto= 0x904;
						strcpy(_current_state1,"SND_TC_DAT");
					}
				break;
				case SYS_RESET:
					sreg=SYS_RESET;

					sto= 0x1000;
					strcpy(_current_state1,"SYS_RESET");
				break;
				default:
				break;
			} /* End switch */
		} /* End if (default) */

		/* -------- machine sreg1 ---------- */
		if ( RES ) {
			sreg1=COM_OFF;
			com_avail=0;
			strcpy(_current_state2,"COM_OFF");
		} else {
			switch(sreg1) {
				case COM_OFF:
					if ( (__sreg==SND_IDLE)& msg_sent ) {
						sreg1=COM_ON;
						com_avail=1;
						strcpy(_current_state2,"COM_ON");
					}
					if ( !msg_sent  |  !(__sreg==SND_IDLE)) {
						sreg1=COM_OFF;
						com_avail=0;
						strcpy(_current_state2,"COM_OFF");
					}
				break;
				case COM_ON:
					if ( (__sreg==SYS_RESET) |  (__sreg==DOM_REBOOT)) {
						sreg1=COM_OFF;
						com_avail=0;
						strcpy(_current_state2,"COM_OFF");
					}
					if ( !(__sreg==SYS_RESET)& !(__sreg==DOM_REBOOT)) {
						sreg1=COM_ON;
						com_avail=1;
						strcpy(_current_state2,"COM_ON");
					}
				break;
				default:
				break;
			} /* End switch */
		} /* End if (default) */

		__sreg=sreg;
		__sreg1=sreg1;
		__buf_res=buf_res;
		__cmd_snd0=cmd_snd0;
		__cmd_snd1=cmd_snd1;
		__cmd_snd2=cmd_snd2;
		__cmd_snd3=cmd_snd3;
		__com_avail=com_avail;
		__COMM_RESET=COMM_RESET;
		__reboot_gnt=reboot_gnt;
		__rec_ena=rec_ena;
		__send_ctrl=send_ctrl;
		__send_data=send_data;
		__send_id=send_id;
		__send_tcal=send_tcal;
		__tcal_cyc=tcal_cyc;
		__tcal_data=tcal_data;
		__tcal_prec=tcal_prec;
		__tcal_psnd=tcal_psnd;
		__timer_clrn=timer_clrn;
		contract_vectors();
	} /*End if (_powerup)*/

	trace_out(_current_state1,_current_state2); /*Trace procedure*/
	return;
}


void trace_in(char _powerup) { /*Trace program flow*/
	printf("\n\t----------------------------------------------");
	_clock++;
	printf("\n\tClock step = %d",_clock);
	if (_powerup) printf("\n\t-Power Up-");
	printf("\n\tInputs:");
	printf("\tbfstat_rcvd=%d",bfstat_rcvd);
	printf("\tcomres_rcvd=%d",comres_rcvd);
	printf("\tdata_rcvd=%d",data_rcvd);
	printf("\tdel_15us=%d",del_15us);
	printf("\n\t\tdel_30us=%d",del_30us);
	printf("\tdpr_rx_aff=%d",dpr_rx_aff);
	printf("\tdpr_tx_ef=%d",dpr_tx_ef);
	printf("\tdrreq_rcvd=%d",drreq_rcvd);
	printf("\tid_data_avail=%d",id_data_avail);
	printf("\n\t\tidle_rcvd=%d",idle_rcvd);
	printf("\tidreq_rcvd=%d",idreq_rcvd);
	printf("\tmsg_sent=%d",msg_sent);
	printf("\tpulse_rcvd=%d",pulse_rcvd);
	printf("\tpulse_sent=%d",pulse_sent);
	printf("\n\t\treboot_req=%d",reboot_req);
	printf("\tRES=%d",RES);
	printf("\tsysres_rcvd=%d",sysres_rcvd);
	printf("\ttcal_rcvd=%d",tcal_rcvd);
	printf("\ttime_bit_5=%d",time_bit_5);
}

void trace_out(char * _current_state1,char * _current_state2) {
	printf("\n\tNext state (sreg) = %s",_current_state1);
	printf("\n\tNext state (sreg1) = %s",_current_state2);
	printf("\n\tOutputs:");
	printf("\tbuf_res=%d",buf_res);
	printf("\tcmd_snd0=%d",cmd_snd0);
	printf("\tcmd_snd1=%d",cmd_snd1);
	printf("\tcmd_snd2=%d",cmd_snd2);
	printf("\n\t\tcmd_snd3=%d",cmd_snd3);
	printf("\tcom_avail=%d",com_avail);
	printf("\tCOMM_RESET=%d",COMM_RESET);
	printf("\treboot_gnt=%d",reboot_gnt);
	printf("\trec_ena=%d",rec_ena);
	printf("\n\t\tsend_ctrl=%d",send_ctrl);
	printf("\tsend_data=%d",send_data);
	printf("\tsend_id=%d",send_id);
	printf("\tsend_tcal=%d",send_tcal);
	printf("\ttcal_cyc=%d",tcal_cyc);
	printf("\n\t\ttcal_data=%d",tcal_data);
	printf("\ttcal_prec=%d",tcal_prec);
	printf("\ttcal_psnd=%d",tcal_psnd);
	printf("\ttimer_clrn=%d",timer_clrn);
}

void condition(char _bfstat_rcvd,char _comres_rcvd,char _data_rcvd,char 
	_del_15us,char _del_30us,char _dpr_rx_aff,char _dpr_tx_ef,char _drreq_rcvd,
	char _id_data_avail,char _idle_rcvd,char _idreq_rcvd,char _msg_sent,char 
	_pulse_rcvd,char _pulse_sent,char _reboot_req,char _RES,char _sysres_rcvd,
	char _tcal_rcvd,char _time_bit_5) {
	bfstat_rcvd=_bfstat_rcvd;
	comres_rcvd=_comres_rcvd;
	data_rcvd=_data_rcvd;
	del_15us=_del_15us;
	del_30us=_del_30us;
	dpr_rx_aff=_dpr_rx_aff;
	dpr_tx_ef=_dpr_tx_ef;
	drreq_rcvd=_drreq_rcvd;
	id_data_avail=_id_data_avail;
	idle_rcvd=_idle_rcvd;
	idreq_rcvd=_idreq_rcvd;
	msg_sent=_msg_sent;
	pulse_rcvd=_pulse_rcvd;
	pulse_sent=_pulse_sent;
	reboot_req=_reboot_req;
	RES=_RES;
	sysres_rcvd=_sysres_rcvd;
	tcal_rcvd=_tcal_rcvd;
	time_bit_5=_time_bit_5;
}

void check_result(enum _sreg_TYPE _sreg,enum _sreg1_TYPE _sreg1,char _buf_res
	,char _cmd_snd0,char _cmd_snd1,char _cmd_snd2,char _cmd_snd3,char _com_avail,
	char _COMM_RESET,char _reboot_gnt,char _rec_ena,char _send_ctrl,char 
	_send_data,char _send_id,char _send_tcal,char _tcal_cyc,char _tcal_data,char 
	_tcal_prec,char _tcal_psnd,char _timer_clrn) {

	char name[64];

	if ((_sreg!=sreg) && (_sreg != _sreg_UNKNOWN)) {
		translate_sreg(sreg,name);
		printf("\nError: state machine sreg is in state=%s",name);
		translate_sreg(_sreg,name);
		printf(" expected to be in state= %s",name);
		_error++;
	}

	if ((_sreg1!=sreg1) && (_sreg1 != _sreg1_UNKNOWN)) {
		translate_sreg1(sreg1,name);
		printf("\nError: state machine sreg1 is in state=%s",name);
		translate_sreg1(_sreg1,name);
		printf(" expected to be in state= %s",name);
		_error++;
	}

	if ((_buf_res!=buf_res) && (_buf_res!=2)) {
		printf("\nError: buf_res= %d expected= %d",buf_res,_buf_res);
		_error++;
	}

	if ((_cmd_snd0!=cmd_snd0) && (_cmd_snd0!=2)) {
		printf("\nError: cmd_snd0= %d expected= %d",cmd_snd0,_cmd_snd0);
		_error++;
	}

	if ((_cmd_snd1!=cmd_snd1) && (_cmd_snd1!=2)) {
		printf("\nError: cmd_snd1= %d expected= %d",cmd_snd1,_cmd_snd1);
		_error++;
	}

	if ((_cmd_snd2!=cmd_snd2) && (_cmd_snd2!=2)) {
		printf("\nError: cmd_snd2= %d expected= %d",cmd_snd2,_cmd_snd2);
		_error++;
	}

	if ((_cmd_snd3!=cmd_snd3) && (_cmd_snd3!=2)) {
		printf("\nError: cmd_snd3= %d expected= %d",cmd_snd3,_cmd_snd3);
		_error++;
	}

	if ((_com_avail!=com_avail) && (_com_avail!=2)) {
		printf("\nError: com_avail= %d expected= %d",com_avail,_com_avail);
		_error++;
	}

	if ((_COMM_RESET!=COMM_RESET) && (_COMM_RESET!=2)) {
		printf("\nError: COMM_RESET= %d expected= %d",COMM_RESET,_COMM_RESET);
		_error++;
	}

	if ((_reboot_gnt!=reboot_gnt) && (_reboot_gnt!=2)) {
		printf("\nError: reboot_gnt= %d expected= %d",reboot_gnt,_reboot_gnt);
		_error++;
	}

	if ((_rec_ena!=rec_ena) && (_rec_ena!=2)) {
		printf("\nError: rec_ena= %d expected= %d",rec_ena,_rec_ena);
		_error++;
	}

	if ((_send_ctrl!=send_ctrl) && (_send_ctrl!=2)) {
		printf("\nError: send_ctrl= %d expected= %d",send_ctrl,_send_ctrl);
		_error++;
	}

	if ((_send_data!=send_data) && (_send_data!=2)) {
		printf("\nError: send_data= %d expected= %d",send_data,_send_data);
		_error++;
	}

	if ((_send_id!=send_id) && (_send_id!=2)) {
		printf("\nError: send_id= %d expected= %d",send_id,_send_id);
		_error++;
	}

	if ((_send_tcal!=send_tcal) && (_send_tcal!=2)) {
		printf("\nError: send_tcal= %d expected= %d",send_tcal,_send_tcal);
		_error++;
	}

	if ((_tcal_cyc!=tcal_cyc) && (_tcal_cyc!=2)) {
		printf("\nError: tcal_cyc= %d expected= %d",tcal_cyc,_tcal_cyc);
		_error++;
	}

	if ((_tcal_data!=tcal_data) && (_tcal_data!=2)) {
		printf("\nError: tcal_data= %d expected= %d",tcal_data,_tcal_data);
		_error++;
	}

	if ((_tcal_prec!=tcal_prec) && (_tcal_prec!=2)) {
		printf("\nError: tcal_prec= %d expected= %d",tcal_prec,_tcal_prec);
		_error++;
	}

	if ((_tcal_psnd!=tcal_psnd) && (_tcal_psnd!=2)) {
		printf("\nError: tcal_psnd= %d expected= %d",tcal_psnd,_tcal_psnd);
		_error++;
	}

	if ((_timer_clrn!=timer_clrn) && (_timer_clrn!=2)) {
		printf("\nError: timer_clrn= %d expected= %d",timer_clrn,_timer_clrn);
		_error++;
	}
}

void translate_sreg(enum _sreg_TYPE _sreg, char * name) {
	if (!name) return;
	switch (_sreg) {
		case CLR_BUF:
			strcpy(name,"CLR_BUF");
		break;
		case CLR_TIMER_1:
			strcpy(name,"CLR_TIMER_1");
		break;
		case CLR_TIMER_2:
			strcpy(name,"CLR_TIMER_2");
		break;
		case CMD_WAIT:
			strcpy(name,"CMD_WAIT");
		break;
		case CRES_WAIT:
			strcpy(name,"CRES_WAIT");
		break;
		case DOM_REBOOT:
			strcpy(name,"DOM_REBOOT");
		break;
		case PON:
			strcpy(name,"PON");
		break;
		case REC_PULSE:
			strcpy(name,"REC_PULSE");
		break;
		case REC_WT:
			strcpy(name,"REC_WT");
		break;
		case SEND_WT_1:
			strcpy(name,"SEND_WT_1");
		break;
		case SEND_WT_2:
			strcpy(name,"SEND_WT_2");
		break;
		case SND_DAT:
			strcpy(name,"SND_DAT");
		break;
		case SND_DRAND:
			strcpy(name,"SND_DRAND");
		break;
		case SND_DRBT:
			strcpy(name,"SND_DRBT");
		break;
		case SND_ID:
			strcpy(name,"SND_ID");
		break;
		case SND_IDLE:
			strcpy(name,"SND_IDLE");
		break;
		case SND_MRNB:
			strcpy(name,"SND_MRNB");
		break;
		case SND_MRWB:
			strcpy(name,"SND_MRWB");
		break;
		case SND_PULSE:
			strcpy(name,"SND_PULSE");
		break;
		case SND_TC_DAT:
			strcpy(name,"SND_TC_DAT");
		break;
		case SYS_RESET:
			strcpy(name,"SYS_RESET");
		break;
		case _sreg_UNKNOWN:
			strcpy(name,"_sreg_UNKNOWN");
		break;
		default:
			sprintf(name,"Unknown enumeration= %d ",_sreg);
		break;
	} /* End switch */
	return;
}
void translate_sreg1(enum _sreg1_TYPE _sreg1, char * name) {
	if (!name) return;
	switch (_sreg1) {
		case COM_OFF:
			strcpy(name,"COM_OFF");
		break;
		case COM_ON:
			strcpy(name,"COM_ON");
		break;
		case _sreg1_UNKNOWN:
			strcpy(name,"_sreg1_UNKNOWN");
		break;
		default:
			sprintf(name,"Unknown enumeration= %d ",_sreg1);
		break;
	} /* End switch */
	return;
}

void error_count() {
	if (_error || _warning) {
		printf("\n\nErrors = %d Warnings = %d\n",_error,_warning);
	} else {
		printf("\n\nSimulation successful, no problems found.\n");
	}
}

void contract_vectors() {

	/* Contract sub-bits of vector sto */
	rec_ena = (char) ((sto >> 16) & 0x1);
	buf_res = (char) ((sto >> 15) & 0x1);
	timer_clrn = (char) ((sto >> 14) & 0x1);
	reboot_gnt = (char) ((sto >> 13) & 0x1);
	COMM_RESET = (char) ((sto >> 12) & 0x1);
	tcal_data = (char) ((sto >> 11) & 0x1);
	tcal_psnd = (char) ((sto >> 10) & 0x1);
	tcal_prec = (char) ((sto >> 9) & 0x1);
	tcal_cyc = (char) ((sto >> 8) & 0x1);
	cmd_snd3 = (char) ((sto >> 7) & 0x1);
	cmd_snd2 = (char) ((sto >> 6) & 0x1);
	cmd_snd1 = (char) ((sto >> 5) & 0x1);
	cmd_snd0 = (char) ((sto >> 4) & 0x1);
	send_id = (char) ((sto >> 3) & 0x1);
	send_tcal = (char) ((sto >> 2) & 0x1);
	send_data = (char) ((sto >> 1) & 0x1);
	send_ctrl = (char) ((sto >> 0) & 0x1);
}

void expand_vectors() {
	sto =((rec_ena & 0x1) << 16) | ((buf_res & 0x1) << 15) | ((timer_clrn & 0x1)
		 << 14) | ((reboot_gnt & 0x1) << 13) | ((COMM_RESET & 0x1) << 12) | ((
		tcal_data & 0x1) << 11) | ((tcal_psnd & 0x1) << 10) | ((tcal_prec & 0x1) << 9
		) | ((tcal_cyc & 0x1) << 8) | ((cmd_snd3 & 0x1) << 7) | ((cmd_snd2 & 0x1) << 
		6) | ((cmd_snd1 & 0x1) << 5) | ((cmd_snd0 & 0x1) << 4) | ((send_id & 0x1) << 
		3) | ((send_tcal & 0x1) << 2) | ((send_data & 0x1) << 1) | ((send_ctrl & 0x1)
		 << 0);
}

unsigned long expand_bit(int width, char value) {
	unsigned long result;
	int count;
	result=0;
	for (count=0; count<width; count++) result |= 
		(((char) value) & 0x1) << count;
	return(result);
}
