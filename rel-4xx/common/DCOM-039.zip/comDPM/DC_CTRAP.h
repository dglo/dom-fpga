#include <stdio.h> /*for printf*/
#include <string.h> /*for strcpy*/

void _DC_CTRAP(char);
void contract_vectors(void);
void expand_vectors(void);

enum _sreg_TYPE {CLR_BUF,CLR_TIMER_1,CLR_TIMER_2,CMD_WAIT,CRES_WAIT,
	DOM_REBOOT,PON,REC_PULSE,REC_WT,SEND_WT_1,SEND_WT_2,SND_DAT,SND_DRAND,
	SND_DRBT,SND_ID,SND_IDLE,SND_MRNB,SND_MRWB,SND_PULSE,SND_TC_DAT,SYS_RESET,
	_sreg_UNKNOWN};

enum _sreg1_TYPE {COM_OFF,COM_ON,_sreg1_UNKNOWN};

void trace_in(char);
void trace_out(char *,char *);
extern int _clock,_error,_warning;
void error_count();
void condition(char, char, char, char, char, char, char, char, char, char, 
	char, char, char, char, char, char, char, char, char);

void check_result(enum _sreg_TYPE, enum _sreg1_TYPE, char, char, char, char, 
	char, char, char, char, char, char, char, char, char, char, char, char, char,
	 char);

void translate_sreg(enum _sreg_TYPE, char *);
void translate_sreg1(enum _sreg1_TYPE, char *);
extern enum _sreg_TYPE sreg,__sreg;
extern enum _sreg1_TYPE sreg1,__sreg1;

extern char bfstat_rcvd,comres_rcvd,data_rcvd,del_15us,del_30us;
extern char dpr_rx_aff,dpr_tx_ef,drreq_rcvd,id_data_avail,idle_rcvd;
extern char idreq_rcvd,msg_sent,pulse_rcvd,pulse_sent,reboot_req;
extern char RES,sysres_rcvd,tcal_rcvd,time_bit_5;


extern char buf_res,__buf_res,cmd_snd0,__cmd_snd0,cmd_snd1,__cmd_snd1,
	cmd_snd2,__cmd_snd2,cmd_snd3,__cmd_snd3;
extern char com_avail,__com_avail,COMM_RESET,__COMM_RESET,reboot_gnt,
	__reboot_gnt,rec_ena,__rec_ena,send_ctrl,__send_ctrl;
extern char send_data,__send_data,send_id,__send_id,send_tcal,__send_tcal,
	tcal_cyc,__tcal_cyc,tcal_data,__tcal_data;
extern char tcal_prec,__tcal_prec,tcal_psnd,__tcal_psnd,timer_clrn,
	__timer_clrn;

extern unsigned long sto,__sto;
unsigned long expand_bit(int, char);
